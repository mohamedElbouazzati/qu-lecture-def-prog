#ifndef HIDDEN_FUNCTIONS_H
#define HIDDEN_FUNCTIONS_H

int copy_file(const char * in, const char * out);

int wait_confirmation(const char * in, const char * out);

#endif // HIDDEN_FUNCTIONS_H